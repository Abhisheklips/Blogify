﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Configuration;
using System.IO;


namespace Blogfiy
{
    public partial class Account : System.Web.UI.Page
    {
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        DataTable table = new DataTable();
        String nam,user_img;
       

        void display_data() {

            //fetching data from database
            String str;
            str = "select * from user_data where user_name=@name";
            cmd = new OleDbCommand(str, con);
            cmd.Parameters.AddWithValue("@name",Request.QueryString["user"]);
            adapter = new OleDbDataAdapter(cmd);
            con.Open();

            cmd.ExecuteNonQuery();
            con.Close();
            adapter.Fill(table);

            //username
            TextBox1.Text = table.Rows[0][0].ToString();
            nam = table.Rows[0][0].ToString();

            // gender
            TextBox2.Text = table.Rows[0][2].ToString();

            //age 
            TextBox3.Text = table.Rows[0][3].ToString();

            //email
            TextBox5.Text = table.Rows[0][4].ToString();
            HiddenField2.Value = table.Rows[0][4].ToString();
            //password
            TextBox4.Text = table.Rows[0][1].ToString();

            //user photo
             HiddenField1.Value = table.Rows[0][6].ToString();
             user_photo.Src = HiddenField1.Value;
            
           

            //date of creation
            //String dor = table.Rows[0][6].ToString();
            //dor = dor.Remove(10);
            //TextBox6.Text = dor;

            //invisible dropdown list

            DropDownList1.Visible = false;
            
        }
     
        protected void Page_Load(object sender, EventArgs e)
        {
           
                //checking authentication 
                if (Request.QueryString["user"] == null)
                {
                    Response.Redirect("login.aspx");
                }
                //making connection to database
                string mainconn = ConfigurationManager.ConnectionStrings["myconnection"].ConnectionString;
                con = new OleDbConnection(mainconn);
                 
                //checking connetion state
                if (con.State == ConnectionState.Open)
                {

                    con.Close();
                }

                if (!IsPostBack) {
                    display_data();
                }
                Button2.Visible = false;
                Button3.Visible = false;
                Label1.Visible = false;
                FileUpload1.Visible = false;
                c_edit.Visible = false;
            
          

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            bool temp = true;
            RequiredFieldValidator1.ErrorMessage = "empty";
            // enable data editing
            if (Button1.Text == "Edit Profile")
            {

                TextBox1.ReadOnly = false;
                TextBox3.ReadOnly = false;
                TextBox4.ReadOnly = false;
                TextBox5.ReadOnly = false;
                TextBox2.Visible = false;
                FileUpload1.Visible = true;
                DropDownList1.Visible = true;
                Button1.Text = "Save";
                Button2.Visible = true;
                c_edit.Visible = true;
            }

                // save changes made by user
            else
            {

                // if changes made in username first we check name is avilable or not

                if (TextBox1.Text!=Request.QueryString["user"].ToString() || TextBox5.Text!=HiddenField2.Value)
                {

                    String str;
                    str = "select [user_name] from [user_data] where [user_name]=@name or mail=@mail";
                    cmd = new OleDbCommand(str, con);
                    cmd.Parameters.AddWithValue("@name", TextBox1.Text);
                    cmd.Parameters.AddWithValue("@mail", TextBox5.Text);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    DataTable table1 = new DataTable();
                    adapter = new OleDbDataAdapter(cmd);
                    adapter.Fill(table1);

                    if (TextBox1.Text != Request.QueryString["user"].ToString()) { 
                          if (table1.Rows.Count == 1)
                          {
                            if (table1.Rows[0][0].ToString() == TextBox1.Text )
                            {
                                RequiredFieldValidator1.ErrorMessage = "username is not avilable";
                                RequiredFieldValidator1.IsValid = false;
                                temp = false;
                            }
                        }

                        if (table1.Rows.Count > 1)
                        {
                            RequiredFieldValidator1.ErrorMessage = "username is not avilable";
                            RequiredFieldValidator1.IsValid = false;
                            temp = false;
                        }
                    
                    }
                    if (TextBox5.Text != HiddenField2.Value)
                    {
                        if (table1.Rows.Count == 1)
                        {
                            if (table1.Rows[0][0].ToString() == TextBox1.Text)
                            {
                                RequiredFieldValidator4.ErrorMessage = "email exist";
                                RequiredFieldValidator4.IsValid = false;
                                temp = false;
                            }
                        }

                        if (table1.Rows.Count > 1)
                        {
                            RequiredFieldValidator4.ErrorMessage = "email exist";
                            RequiredFieldValidator4.IsValid = false;
                            temp = false;
                        }

                    }

                  

                    

                }

                // updating data in user_data table
                if (temp == true)
                {
                    // saving user image in folder
                    if (FileUpload1.HasFile)
                    {
                        //image saving location 
                        HiddenField1.Value = "G:/project/finalproject/Blogfiy2.2/Blogfiy/images/" + TextBox1.Text + ".jpg";
                        FileUpload1.SaveAs(HiddenField1.Value);
                        HiddenField1.Value = "../images/" + TextBox1.Text + ".jpg";
                    }

                    // if user name  change the name in all her posts

                    if (TextBox1.Text != Request.QueryString["user"].ToString()) {
                        String str5 = "update post_data set user_name=@name where user_name=@oldname";
                        cmd = new OleDbCommand(str5,con);
                        cmd.Parameters.AddWithValue("@name",TextBox1.Text);
                        cmd.Parameters.AddWithValue("@oldname",Request.QueryString["user"].ToString());
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();

                        str5 = "update comment_data set user_name=@name where user_name=@oldname";
                        cmd = new OleDbCommand(str5, con);
                        cmd.Parameters.AddWithValue("@name", TextBox1.Text);
                        cmd.Parameters.AddWithValue("@oldname", Request.QueryString["user"].ToString());
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();

                    }
                       

                    String str;
                    str = "UPDATE [user_data] SET [gender]=@gen , [age]=@age , [user_name]=@name , [password]=@pass , [mail]=@mail ,[image]=@image WHERE [user_name]=@name2";

                    cmd = new OleDbCommand(str, con);
                    cmd.Parameters.AddWithValue("@gen", DropDownList1.SelectedItem.Text);
                    cmd.Parameters.AddWithValue("@age", TextBox3.Text);
                    cmd.Parameters.AddWithValue("@name", TextBox1.Text);
                    cmd.Parameters.AddWithValue("@pass", TextBox4.Text);
                    cmd.Parameters.AddWithValue("@maile", TextBox5.Text);
                    cmd.Parameters.AddWithValue("@image", HiddenField1.Value);
                    cmd.Parameters.AddWithValue("@name2", Request.QueryString["user"].ToString());
                    
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    TextBox2.Visible = true;
                    DropDownList1.Visible = false;
                    TextBox1.ReadOnly = true;
                    TextBox3.ReadOnly = true;
                    TextBox4.ReadOnly = true;
                    TextBox5.ReadOnly = true;
                    FileUpload1.Visible = false;
                    c_edit.Visible = false;
                    Button1.Text = "Edit Profile";
                    Response.Redirect("Account.aspx?user=" + TextBox1.Text);
                    //Response.Redirect("login.aspx");
                }
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Label1.Visible = true;
            Button3.Visible = true;
            Button2.Visible = false;
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            // deleting user account 

            String str;
            str = "delete from user_data where user_name=@name";
            cmd = new OleDbCommand(str, con);
            cmd.Parameters.AddWithValue("@name", Request.QueryString["user"].ToString());
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            str = "delete from post_data where user_name=@name";
            cmd = new OleDbCommand(str, con);
            cmd.Parameters.AddWithValue("@name", Request.QueryString["user"].ToString());
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            Response.Redirect("login.aspx");

        }
        //protected void delete_post_click(object sender, EventArgs e)
        //{
        //    Button btn = sender as  Button;
        //    String str = "delete from post_data where ID=@id";
        //    cmd = new OleDbCommand(str, con);
        //    cmd.Parameters.AddWithValue("@id",btn.CommandArgument);
        //    con.Open();
        //    cmd.ExecuteNonQuery();
        //    con.Close();
            
            
        //}

        protected void Button4_Click(object sender, EventArgs e)
        {
            Button btn = sender as  Button;
            if (Request.QueryString["user"] == null)
            {

                Response.Redirect("read_more.aspx?post_id=" + btn.CommandArgument);
            }
            else
            {
                Response.Redirect("read_more.aspx?post_id=" + btn.CommandArgument + "&user=" + Request.QueryString["user"]);

            }
        }

       

        protected void Button5_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            String str = "delete from post_data where ID=@id";
            cmd = new OleDbCommand(str, con);
            cmd.Parameters.AddWithValue("@id", btn.CommandArgument);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Repeater1.DataBind();
        }

        protected void c_edit_Click(object sender, EventArgs e)
        {
            Response.Redirect("Account.aspx?user="+Request.QueryString["user"]);
        }

        }

        

        
              
         

       
        
        
    }
