﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Configuration;
namespace Blogfiy.admin_page

{
       
    public partial class WebForm1 : System.Web.UI.Page
    {
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        DataTable table = new DataTable();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["user"] == null)
            {
                Response.Redirect("~/admin page/admin_login.aspx");
            }
            if (!IsPostBack) {
                box2.Visible = false;
                box3.Visible = false;
            }
            
            //making connection to database
            string mainconn = ConfigurationManager.ConnectionStrings["myconnection"].ConnectionString;
            con = new OleDbConnection(mainconn);

            //checking connetion state
            if (con.State == ConnectionState.Open)
            {

                con.Close();
            }
            
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            box2.Visible = false;
            box3.Visible = false;
            box1.Visible = true;
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            box2.Visible = true;
            box3.Visible = false;
            box1.Visible = false;
        }

        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            box2.Visible = false;
            box3.Visible = true;
            box1.Visible = false;
        }

        protected void delete_Click(object sender, EventArgs e)
        {
            //Label1.Visible = true;
            //no.Visible = true;
            //yes.Visible = true;
            //delete.Visible = false;
            //view_detail.Visible = false;
           
        }

        protected void view_detail_Click(object sender, EventArgs e)
        {
            Button btn =sender as Button;
            Response.Redirect("~/Account.aspx?user="+btn.CommandArgument+"&admin=yes");
        }

        protected void no_Click(object sender, EventArgs e)
        {
            Button btn1 = sender as Button;
            Button btn2 = btn1.Parent.FindControl("yes") as Button;
            Button btn3 = btn1.Parent.FindControl("delete") as Button;
            Label lb = btn1.Parent.FindControl("Label1") as Label;
            btn2.Visible = false;
            lb.Visible = false;        
            btn3.Visible = true;
            btn1.Visible = false;
        }

        protected void yes_Click(object sender, EventArgs e)
        {
            // deleting user account 
            Button btn =sender as Button;
            String str;
            str = "delete from user_data where user_name=@name";
            cmd = new OleDbCommand(str, con);
            cmd.Parameters.AddWithValue("@name", btn.CommandArgument);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            str = "delete from post_data where user_name=@name";
            cmd = new OleDbCommand(str, con);
            cmd.Parameters.AddWithValue("@name", btn.CommandArgument);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Repeater1.DataBind();
        }

        protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
           
            Button btn2 = e.Item.FindControl("yes") as Button;
            Button btn3 = e.Item.FindControl("no") as Button;
            Label lb = e.Item.FindControl("Label1") as Label;
            btn2.Visible = false;
            btn3.Visible = false;
            lb.Visible = false;
            
        }

        protected void delete_Click1(object sender, EventArgs e)
        {
            Button btn1 = sender as Button;
            Button btn2= btn1.Parent.FindControl("yes") as Button;
            Button btn3 = btn1.Parent.FindControl("no") as Button;
            Label lb = btn1.Parent.FindControl("Label1") as Label;
            btn2.Visible = true;
            btn3.Visible = true;
            lb.Visible = true;
            btn1.Visible = false;
           
        }

 

       

        protected void readmore_Click(object sender, EventArgs e)
        {
            Button btn =sender as Button;
            Response.Redirect("~/admin page/admin_readmore.aspx?post_id="+btn.CommandArgument+"&user=Blogify");
        }

        protected void verfiy_Click(object sender, EventArgs e)
        {
            Button btn = (sender) as Button;


            if (btn.Text == "confirm")
            {
                String str = "update post_data set status=" + " 'live' " + "where ID=" + btn.CommandArgument;
                cmd = new OleDbCommand(str, con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                Repeater2.DataBind();
            }
            else
            {
                btn.Text = "confirm";
                Label lb = btn.Parent.FindControl("Label2") as Label;
                Button bt2 = btn.Parent.FindControl("cancel_op") as Button;
                Button bt3 = btn.Parent.FindControl("reject_P") as Button;
                bt3.Text = "reject";
                lb.Visible = true;
                bt2.Visible = true;
            }
        }

        protected void done_Click(object sender, EventArgs e)
        {

        }

        protected void reject_P_Click(object sender, EventArgs e)
        {
            Button btn = (sender) as Button;
            

            if (btn.Text == "confirm")
            {
                String str = "update post_data set status=" + " 'rejected' " + "where ID=" + btn.CommandArgument;
                cmd = new OleDbCommand(str, con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                Repeater2.DataBind();
            }
            else {
                btn.Text = "confirm";
                
                Label lb = btn.Parent.FindControl("Label2") as Label;
                Button bt2 = btn.Parent.FindControl("cancel_op") as Button;
                Button bt3 = btn.Parent.FindControl("verfiy") as Button;
                bt3.Text = "verify";
                lb.Visible = true;
                bt2.Visible = true;
                
            }
        }

        protected void Repeater2_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            Button cancel = e.Item.FindControl("cancel_op") as Button;
            Label lb = e.Item.FindControl("Label2") as Label;
            cancel.Visible = false;
            lb.Visible = false;

        }

        protected void Cancel_op_Click(object sender, EventArgs e)
        {
            Button bt = sender as Button;
            Label lb = bt.Parent.FindControl("Label2")as Label;
            Button bt2 = bt.Parent.FindControl("reject_p") as Button;
            lb.Visible = false;
            bt2.Text = "Reject";
            bt.Visible = false;

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
              //readmore
            Button btn = (sender) as Button;
            Response.Redirect("~/admin page/admin_readmore.aspx?post_id=" + btn.CommandArgument + "&user=Blogify");
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
               //delete post
            Button btn = (sender) as Button;
            if (btn.Text == "confirm")
            {
               
                String str = "delete from post_data where ID=@id";
                cmd = new OleDbCommand(str, con);
                cmd.Parameters.AddWithValue("@id", btn.CommandArgument);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                Repeater3.DataBind();

            }
            else {
                btn.Text = "confirm";
                Label lb = btn.Parent.FindControl("Label3") as Label;
                Button bt2 = btn.Parent.FindControl("Button1") as Button;
                lb.Visible = true;
                bt2.Visible = true;
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Button bt = sender as Button;
            Label lb = bt.Parent.FindControl("Label3") as Label;
            Button bt2 = bt.Parent.FindControl("Button5") as Button;
            lb.Visible = false;
            bt2.Text = "Delete";
            bt.Visible = false;
        }

        protected void Repeater3_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            Button bt = e.Item.FindControl("Button1")as Button;
            Label lb = e.Item.FindControl("Label3") as Label;
            bt.Visible = false;
            lb.Visible = false;

        }


      

        
    }
}