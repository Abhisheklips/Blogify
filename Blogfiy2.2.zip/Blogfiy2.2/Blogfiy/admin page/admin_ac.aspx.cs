﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Configuration;
using System.IO;
namespace Blogfiy.admin_page
{
    public partial class admin_account : System.Web.UI.Page
    {
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        DataTable table = new DataTable();
        String nam;
        void display_data() {

            //fetching data from database
            String str;
            str = "select * from admin_data ";
            cmd = new OleDbCommand(str, con);
            adapter = new OleDbDataAdapter(cmd);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            adapter.Fill(table);

            //username
            TextBox1.Text = table.Rows[0][1].ToString();
            nam = table.Rows[0][0].ToString();
            TextBox4.Text = table.Rows[0][2].ToString();

            //user photo
             HiddenField1.Value = table.Rows[0][3].ToString();
             user_photo.Src = HiddenField1.Value;
            
        }
     
        protected void Page_Load(object sender, EventArgs e)
        {
           
                //checking authentication 
            if (Request.QueryString["user"] == null)
            {
                Response.Redirect("~/admin page/admin_login.aspx");
            }
                //making connection to database
                string mainconn = ConfigurationManager.ConnectionStrings["myconnection"].ConnectionString;
                con = new OleDbConnection(mainconn);
                 
                //checking connetion state
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                if (!IsPostBack) {
                    display_data();
                }
                FileUpload1.Visible = false;
                c_edit.Visible = false;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            bool temp = true;
            RequiredFieldValidator1.ErrorMessage = "empty";
            // enable data editing
            if (Button1.Text == "Edit Profile")
            {
                TextBox4.ReadOnly = false;
                FileUpload1.Visible = true;
                Button1.Text = "Save";
                c_edit.Visible = true;
            }  
            else
                // save changes made by user
            {
                // updating data in user_data table
                if (temp == true)
                {
                    // saving user image in folder
                    if (FileUpload1.HasFile)
                    {
                        //image saving location 
                        HiddenField1.Value = "G:/project/finalproject/Blogfiy2.2/Blogfiy/images/" + TextBox1.Text + ".jpg";
                        FileUpload1.SaveAs(HiddenField1.Value);
                        HiddenField1.Value = "../images/" + TextBox1.Text + ".jpg";
                    }
                    String str;
                    str = "UPDATE [admin_data] SET  [passwd]=@pass ,[image]=@image WHERE ID=1";
                    cmd = new OleDbCommand(str, con);
                    cmd.Parameters.AddWithValue("@pass", TextBox4.Text);
                    cmd.Parameters.AddWithValue("@image", HiddenField1.Value);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    TextBox1.ReadOnly = true;
                    TextBox4.ReadOnly = true;
                    FileUpload1.Visible = false;
                    c_edit.Visible = false;
                    Button1.Text = "Edit Profile";
                    Response.Redirect("~/admin page/admin_ac.aspx?user=Blogify");
                }
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Button btn = sender as  Button;
            if (Request.QueryString["user"] == null)
            {
                Response.Redirect("~/admin page/admin_readmore.aspx?post_id=" + btn.CommandArgument + "&user=Blogify");
            }
            else
            {
                Response.Redirect("read_more.aspx?post_id=" + btn.CommandArgument + "&user=Blogify");
            }
        }
        protected void Button5_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            String str = "delete from post_data where ID=@id";
            cmd = new OleDbCommand(str, con);
            cmd.Parameters.AddWithValue("@id", btn.CommandArgument);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Repeater1.DataBind();
        }

        protected void c_edit_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/admin page/admin_ac.aspx?user="+Request.QueryString["user"]);
        }

        }
    }
