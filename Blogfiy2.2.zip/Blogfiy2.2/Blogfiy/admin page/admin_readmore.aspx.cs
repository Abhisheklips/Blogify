﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data;
using System.Configuration;

namespace Blogfiy.admin_page
{
    public partial class admin_readmore : System.Web.UI.Page
    {
        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        DataTable table = new DataTable();
        String reaction;
        String categ;

        protected void Page_Load(object sender, EventArgs e)
        {
            // to hide comment box 
            if (!IsPostBack)
            {
                comment_container.Visible = false;
            }


            // making connection with database 
            string mainconn = ConfigurationManager.ConnectionStrings["myconnection"].ConnectionString;
            con = new OleDbConnection(mainconn);

            if (con.State == ConnectionState.Open)
            {

                con.Close();
            }
            con.Open();
            //geting the data of article 

            String str = "select * from post_data where ID=@post_id";
            cmd = new OleDbCommand(str, con);
            cmd.Parameters.AddWithValue("@post_id", Request.QueryString["post_id"].ToString());

            cmd.ExecuteNonQuery();
            con.Close();
            adapter = new OleDbDataAdapter(cmd);
            adapter.Fill(table);

            // set the article value to page

            post_title.InnerText = table.Rows[0][2].ToString();
            post_date.InnerText = "Posted On: " + (table.Rows[0][9].ToString());
            Image1.ImageUrl = "../"+table.Rows[0][5].ToString();
            desc.InnerText = (table.Rows[0][3].ToString());
            post_article.InnerText = table.Rows[0][4].ToString();
            post_author.InnerHtml = "Posted By:" + (table.Rows[0][1].ToString());
            post_views.InnerText = "Views: " + (table.Rows[0][8].ToString());
            Like_count.Text = table.Rows[0][6].ToString();
            Dislike_count.Text = table.Rows[0][7].ToString();
            HiddenField1.Value = table.Rows[0][10].ToString();

            // set the default reaction of user nothing if user is logined
            if (Request.QueryString["user"] != null)
            {

                str = "select * from like_dislike_data where post_id=@id and user_name=@user";
                cmd = new OleDbCommand(str, con);
                cmd.Parameters.AddWithValue("@id", Request.QueryString["post_id"].ToString());
                cmd.Parameters.AddWithValue("@user", Request.QueryString["user"].ToString());
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                adapter = new OleDbDataAdapter(cmd);
                table = new DataTable();
                adapter.Fill(table);


                // get the current date and time 
                String dor = DateTime.Today.ToString();
                dor = dor.Remove(10);

                if (table.Rows.Count == 0)
                {
                    //Response.Redirect("login.aspx");
                    str = "insert into like_dislike_data values(@username, @postid ,@reaction, @doc,@report)";
                    cmd = new OleDbCommand(str, con);
                    cmd.Parameters.AddWithValue("@username", Request.QueryString["user"].ToString());
                    cmd.Parameters.AddWithValue("@postid", Request.QueryString["post_id"].ToString());
                    cmd.Parameters.AddWithValue("@reaction", "nothing");
                    cmd.Parameters.AddWithValue("@doc", dor);
                    cmd.Parameters.AddWithValue("@report", 0);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    reaction = "nothing";
                }
                else
                {
                    reaction = table.Rows[0][2].ToString();
                }


            }




        }



        // set_reaction will set the user reaction on this post
        void set_reaction(String value)
        {
            String str = "update like_dislike_data set reaction=@value where user_name=@user and post_id=@id";
            cmd = new OleDbCommand(str, con);
            cmd.Parameters.AddWithValue("@value", value);
            cmd.Parameters.AddWithValue("@user", Request.QueryString["user"]);
            cmd.Parameters.AddWithValue("@id", Request.QueryString["post_id"]);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

        // funtion will be trigger when comment button is clicked 
        protected void button1_click(object sender, EventArgs e)
        {
            if (comment_container.Visible == true)
            {
                comment_container.Visible = false;
            }
            else
            {
                comment_container.Visible = true;
            }


        }

        protected void like_click(object sender, EventArgs e)
        {   //check the reaction of user

            if (Request.QueryString["user"] != null)
            {
                String str = "";
                bool temp = false;

                if (reaction == "nothing")
                {
                    Like_count.Text = (int.Parse(Like_count.Text) + 1).ToString();
                    set_reaction("like");   //set reaction
                    str = "update post_data pd set pd.likes=pd.likes+1 where ID=@id";
                    temp = true;


                }

                else if (reaction == "dislike")
                {
                    Like_count.Text = (int.Parse(Like_count.Text) + 1).ToString();
                    Dislike_count.Text = (int.Parse(Dislike_count.Text) - 1).ToString();
                    // if reaction = dislike then in post_data like+1 dislike-1 
                    set_reaction("like");
                    str = "update post_data pd set pd.likes=pd.likes+1 , pd.dislikes=pd.dislikes-1  where ID=@id";
                    temp = true;

                }
                else
                {
                    //nothing 
                }

                if (temp)
                {
                    cmd = new OleDbCommand(str, con);
                    cmd.Parameters.AddWithValue("@id", Request.QueryString["post_id"].ToString());
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }



            }
        }

        protected void dislike_click(object sender, EventArgs e)
        {
            if (Request.QueryString["user"] != null)
            {
                String str = "";
                bool temp = false;
                if (reaction == "nothing")
                {
                    Dislike_count.Text = (int.Parse(Dislike_count.Text) + 1).ToString();
                    set_reaction("dislike");   //set reaction
                    str = "update post_data pd set pd.dislikes+1 where ID=@id";
                    temp = true;

                }

                if (reaction == "like")
                {
                    Dislike_count.Text = (int.Parse(Dislike_count.Text) + 1).ToString();
                    Like_count.Text = (int.Parse(Like_count.Text) - 1).ToString();
                    // if reaction = dislike then in post_data like+1 dislike-1 
                    set_reaction("dislike");
                    str = "update post_data pd set pd.likes=pd.likes-1 , pd.dislikes=pd.dislikes+1  where ID=@id";
                    temp = true;

                }

                if (temp)
                {
                    cmd = new OleDbCommand(str, con);
                    cmd.Parameters.AddWithValue("@id", Request.QueryString["post_id"].ToString());
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }


        // deleting user comment from database 
        protected void Button2_Click(object sender, EventArgs e)
        {
            Button btn = (sender) as Button;
            String str = "delete from comment_data where coment_id=@id";
            cmd = new OleDbCommand(str, con);
            cmd.Parameters.AddWithValue("@id", btn.CommandArgument.ToString());
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Repeater1.DataBind();

        }

        protected void submit_Click(object sender, EventArgs e)
        {

            if (Request.QueryString["user"] != null)
            {
                if (button1.InnerText.Length > 0)
                {
                    string mainconn = ConfigurationManager.ConnectionStrings["myconnection"].ConnectionString;
                    con = new OleDbConnection(mainconn);
                    if (con.State == ConnectionState.Open)
                    {

                        con.Close();
                    }


                    // creating id for new comment
                    String str = "select MAX(coment_id) from comment_data";
                    cmd = new OleDbCommand(str, con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    int id = (int)(cmd.ExecuteScalar());
                    con.Close();
                    id = id + 1;

                    // get the current date
                    String dor = DateTime.Today.ToString();
                    dor = dor.Remove(10);

                    str = "insert into comment_data values(@user_name,@comment,@doc,@post_id,@coment_id)";
                    cmd = new OleDbCommand(str, con);
                    cmd.Parameters.AddWithValue("@user_name", Request.QueryString["user"].ToString());
                    cmd.Parameters.AddWithValue("@comment", TextBox1.Text);
                    cmd.Parameters.AddWithValue("@doc", dor);
                    cmd.Parameters.AddWithValue("@post_id", Request.QueryString["post_id"].ToString());
                    cmd.Parameters.AddWithValue("@coment_id", id);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    TextBox1.Text = null;
                    Repeater1.DataBind();

                }

            }



        }

        protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            Button btn = e.Item.FindControl("Button2") as Button;
            Label user = e.Item.FindControl("Label1") as Label;
            btn.Visible = false;
            if (Request.QueryString["user"] != null)
            {

                if (user.Text == Request.QueryString["user"].ToString())
                {
                    btn.Visible = true;
                }
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Button btn = (sender) as Button;
            String str = "update post_data pd set pd.views=pd.views+1 where ID=@id ";
            cmd = new OleDbCommand(str, con);
            cmd.Parameters.AddWithValue("@id", btn.CommandArgument.ToString());
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            if (Request.QueryString["user"] == null)
            {

                Response.Redirect("~/admin page/admin_readmore.aspx?post_id=" + btn.CommandArgument);
            }
            else
            {
                Response.Redirect("~/admin page/admin_readmore.aspx?post_id=" + btn.CommandArgument + "&user=Blogify");

            }
        }

       

    }
}