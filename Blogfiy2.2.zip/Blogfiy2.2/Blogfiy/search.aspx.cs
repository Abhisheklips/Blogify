﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

namespace Blogfiy
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        OleDbConnection con;
        OleDbCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            // making connection with database 
            string mainconn = ConfigurationManager.ConnectionStrings["myconnection"].ConnectionString;
            con = new OleDbConnection(mainconn);

            if (con.State == ConnectionState.Open)
            {

                con.Close();
            }    
        }

        protected void readmore_Click(object sender, EventArgs e)
        {
            // redirect to readmore page and count+1 in views in post_data table field
            Button btn = (sender) as Button;
            String str = "update post_data pd set pd.views=pd.views+1 where ID=@id ";
            cmd = new OleDbCommand(str, con);
            cmd.Parameters.AddWithValue("@id", btn.CommandArgument.ToString());
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            if (Request.QueryString["user"] == null)
            {

                Response.Redirect("read_more.aspx?post_id=" + btn.CommandArgument);
            }
            else
            {
                Response.Redirect("read_more.aspx?post_id=" + btn.CommandArgument + "&user=" + Request.QueryString["user"]);

            }
        }

        protected void ListView1_ItemDataBound(object sender, ListViewItemEventArgs e)
        {
            Button btn = e.Item.FindControl("readmore") as Button;
            btn.Click += new EventHandler(readmore_Click);
        }

       
    }
}