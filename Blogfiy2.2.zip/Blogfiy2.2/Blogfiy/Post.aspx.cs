﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data;
using System.Configuration;

namespace Blogfiy
{
    public partial class Post : System.Web.UI.Page
    {
        OleDbConnection con;
        OleDbCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            //checking authentication 
            if (Request.QueryString["user"] == null)
            {
                Response.Redirect("login.aspx");
            }

            string mainconn = ConfigurationManager.ConnectionStrings["myconnection"].ConnectionString;
            con = new OleDbConnection(mainconn);

            if (con.State == ConnectionState.Open)
            {

                con.Close();
            }
            //desc.MaxLength = 50;
            //Article.MaxLength = 100;
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           
            //if (FileUpload1.HasFile == true)
            //{
            //    RequiredFieldValidator4.IsValid = true;
            //}
            //else {
            //    RequiredFieldValidator4.IsValid = false;
            //}

            // get the current date and time 
            String dor = DateTime.Today.ToString();
            dor = dor.Remove(10);

            String str;

             // creating id for new post
                  str="select MAX(ID) from post_data";
                  cmd = new OleDbCommand(str, con);
                  con.Open();
                  cmd.ExecuteNonQuery();
                  int id = (int)(cmd.ExecuteScalar());
                  con.Close();
                  id = id + 1;

            // saving image in folder
                String f_name=FileUpload1.FileName;
                String location="G:/project/finalproject/Blogfiy2.2/Blogfiy/images/"+id+".jpg";
                FileUpload1.SaveAs(location);
            
                str = "insert into [post_data] values(@id,@username,@title,@des,@content,@image,@like,@dislike,@views,@date,@category,@status)";
                cmd = new OleDbCommand(str, con);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@username",Request.QueryString["user"].ToString());
                cmd.Parameters.AddWithValue("@title", title.Text);
                cmd.Parameters.AddWithValue("@des",desc.InnerText);
                cmd.Parameters.AddWithValue("@content", Article.InnerText);
                cmd.Parameters.AddWithValue("@image",("images/"+id+".jpg"));
                cmd.Parameters.AddWithValue("@like", 0);
                cmd.Parameters.AddWithValue("@dislike",0);
                cmd.Parameters.AddWithValue("@view", 0);
                cmd.Parameters.AddWithValue("@date", dor); 
                cmd.Parameters.AddWithValue("@category",DropDownList1.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@status","pending");
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                Response.Redirect("main.aspx?user="+Request.QueryString["user"].ToString());

               
            
        }

     
    }
}