﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data;
using System.Configuration;


namespace Blogfiy
{
    public partial class SingUp : System.Web.UI.Page
    {

        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        DataTable table = new DataTable();
        string img5 = "~/Assets/Image/user_profile_male.jpg";
        protected void Page_Load(object sender, EventArgs e)
        {
            string mainconn = ConfigurationManager.ConnectionStrings["myconnection"].ConnectionString;
            con = new OleDbConnection(mainconn);
            
            if (con.State == ConnectionState.Open)
            {

                con.Close();
            }

            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            // checking user name is avilable or not 
            String str;
            RequiredFieldValidator6.ErrorMessage="Enter the name";
            RequiredFieldValidator4.ErrorMessage = "Enter the email";
            str="select user_name,mail from user_data where user_name=@name or mail=@mail";
            cmd = new OleDbCommand(str, con);
            cmd.Parameters.AddWithValue("@name",username.Text);
            cmd.Parameters.AddWithValue("@mail",emailtext.Text);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            adapter=new OleDbDataAdapter(cmd);
            adapter.Fill(table);

            if (table.Rows.Count==1)
            {

                if (table.Rows[0][0].ToString() == username.Text && table.Rows[0][1].ToString() != emailtext.Text)
                {
                    RequiredFieldValidator6.ErrorMessage = "username is not avilable";
                    RequiredFieldValidator6.IsValid = false;
                }
                else if (table.Rows[0][1].ToString() == emailtext.Text && table.Rows[0][0].ToString() != username.Text)
                {
                    RequiredFieldValidator4.ErrorMessage = "email is already exist";
                    RequiredFieldValidator4.IsValid = false;
                }
                else
                {
                    RequiredFieldValidator6.ErrorMessage = "username is not avilable";
                    RequiredFieldValidator4.ErrorMessage = "email is already exist";
                    RequiredFieldValidator4.IsValid = false;
                    RequiredFieldValidator6.IsValid = false;
                }
            }

            else if(table.Rows.Count>1){

                RequiredFieldValidator6.ErrorMessage = "username is not avilable";
                RequiredFieldValidator4.ErrorMessage = "email is already exist";
                RequiredFieldValidator4.IsValid = false;
                RequiredFieldValidator6.IsValid = false;
                
            }

         
            else {
                  
                  //inserting data in database table user_data
                  String dor = DateTime.Today.ToString();
                  dor = dor.Remove(10);

                // set image according to gender
                  if (DropDownList1.SelectedItem.Text == "Female")
                  {
                      img5 = "~/Assets/Image/user_profile_female.jpg";
                  }
             

                  str = "insert into user_data values(@name,@pass,@gender,@age,@mail,@dor,@image)";
                  cmd = new OleDbCommand(str, con);
      
                  cmd.Parameters.AddWithValue("@name",username.Text);
                  cmd.Parameters.AddWithValue("@pass",Passwordtext.Text);
                  cmd.Parameters.AddWithValue("@gender",DropDownList1.SelectedItem.Text);
                  cmd.Parameters.AddWithValue("@age",TextBox5.Text);
                  cmd.Parameters.AddWithValue("@mail",emailtext.Text);
                  cmd.Parameters.AddWithValue("@dor",dor);
                  cmd.Parameters.AddWithValue("@image", img5);
                  con.Open();
                  cmd.ExecuteNonQuery();
                  con.Close();

                  Response.Redirect("main.aspx?user="+username.Text);
            }

                     
            


        }

       

       
    }
}