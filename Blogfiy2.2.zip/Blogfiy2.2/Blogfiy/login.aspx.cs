﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Data.OleDb;
using System.Configuration;



namespace Blogfiy
{
    public partial class logSign : System.Web.UI.Page
    {

        OleDbConnection con;
        OleDbCommand cmd;
        OleDbDataAdapter adapter;
        DataTable table = new DataTable();
        String user1, pass;
        protected void Page_Load(object sender, EventArgs e)
        {
            string mainconn = ConfigurationManager.ConnectionStrings["myconnection"].ConnectionString;
            con = new OleDbConnection(mainconn);
            if (con.State == ConnectionState.Open)
            {

                con.Close();
            }
          
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            RequiredFieldValidator1.ErrorMessage = "empty";
            RequiredFieldValidator2.ErrorMessage = "empty";
            String str;
            str = "select name,password from user_data where user_name=@name";
            cmd = new OleDbCommand(str, con);
            cmd.Parameters.AddWithValue("@name",usertext.Text);
            adapter = new OleDbDataAdapter(cmd);
            con.Open();

            cmd.ExecuteNonQuery();
            con.Close();
            adapter.Fill(table);
            if (table.Rows.Count > 0)
            {
               
                user1 = (string)table.Rows[0][0];
                pass = (string)table.Rows[0][1];
               

                if (pass != passtext.Text)
                {
                    RequiredFieldValidator2.ErrorMessage = "incorrect";
                    RequiredFieldValidator2.IsValid = false;
                }

                else {
                    if (Request.QueryString["page"] != null) {
                        Response.Redirect(Request.QueryString["page"]+ ".aspx?user=" + user1);
                    }
                    Response.Redirect("main.aspx?user=" + user1);
                }

            }
            else {
                RequiredFieldValidator1.ErrorMessage = "username not founded";
                RequiredFieldValidator1.IsValid = false;
                
            }

           

                        
        }
    }
}