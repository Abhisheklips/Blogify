﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;




namespace Blogfiy
{
    public partial class home : System.Web.UI.MasterPage
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            

            if (Request.QueryString["user"] != null && Request.QueryString["admin"] == null)
            {

                HyperLink1.Text = "logout";
                HyperLink2.Visible = false;
                HyperLink1.NavigateUrl = "main.aspx";
                HyperLink3.NavigateUrl = "Account.aspx?user=" + Request.QueryString["user"];

                post_link.NavigateUrl = ("Post.aspx?user=" + Request.QueryString["user"]);
                about_link.NavigateUrl = ("about.aspx?user=" + Request.QueryString["user"]);
                
                Home_link.NavigateUrl = ("main.aspx?user=" + Request.QueryString["user"]);


                HyperLink4.NavigateUrl = ("category.aspx?category=Movie" + "&user=" + Request.QueryString["user"]);
                HyperLink5.NavigateUrl = ("category.aspx?category=Food" + "&user=" + Request.QueryString["user"]);
                HyperLink6.NavigateUrl = ("category.aspx?category=Sports" + "&user=" + Request.QueryString["user"]);
                HyperLink7.NavigateUrl = ("category.aspx?category=Education" + "&user=" + Request.QueryString["user"]);
                HyperLink8.NavigateUrl = ("category.aspx?category=Technology" + "&user=" + Request.QueryString["user"]);
                HyperLink9.NavigateUrl = ("category.aspx?category=Other" + "&user=" + Request.QueryString["user"]);

            }
            else if (Request.QueryString["user"] != null && Request.QueryString["admin"]!=null)
            {
                HyperLink1.Text = "logout from user";
                HyperLink2.Visible = false;
                HyperLink1.NavigateUrl = "~/admin page/admin_home.aspx";
                HyperLink3.NavigateUrl = "Account.aspx?user=" + Request.QueryString["user"] +"&admin=yes";

                post_link.NavigateUrl = ("Post.aspx?user=" + Request.QueryString["user"] + "&admin=yes");
                about_link.NavigateUrl = ("about.aspx?user=" + Request.QueryString["user"] + "&admin=yes");

                Home_link.NavigateUrl = ("main.aspx?user=" + Request.QueryString["user"] + "&admin=yes");


                HyperLink4.NavigateUrl = ("category.aspx?category=Movie" + "&user=" + Request.QueryString["user"] + "&admin=yes");
                HyperLink5.NavigateUrl = ("category.aspx?category=Food" + "&user=" + Request.QueryString["user"] + "&admin=yes");
                HyperLink6.NavigateUrl = ("category.aspx?category=Sports" + "&user=" + Request.QueryString["user"] + "&admin=yes");
                HyperLink7.NavigateUrl = ("category.aspx?category=Education" + "&user=" + Request.QueryString["user"] + "&admin=yes");
                HyperLink8.NavigateUrl = ("category.aspx?category=Technology" + "&user=" + Request.QueryString["user"] + "&admin=yes");
                HyperLink9.NavigateUrl = ("category.aspx?category=Other" + "&user=" + Request.QueryString["user"] + "&admin=yes");
            
            }
            else {
                HyperLink1.Text = "login";
                HyperLink2.Text = "sign_up";
                HyperLink1.NavigateUrl = "login.aspx";
                HyperLink2.NavigateUrl = "SignUp.aspx";
                HyperLink3.Visible = false;

                post_link.NavigateUrl = ("Post.aspx");
                about_link.NavigateUrl = ("About.aspx");
                Home_link.NavigateUrl = ("main.aspx");

                //HyperLink4.NavigateUrl = ("category.aspx?category=Moive");
                //HyperLink5.NavigateUrl = ("category.aspx?category=Food");
                //HyperLink6.NavigateUrl = ("category.aspx?category=Sports");
                //HyperLink7.NavigateUrl = ("category.aspx?category=Education");
                //HyperLink8.NavigateUrl = ("category.aspx?category=Technology");
                //HyperLink9.NavigateUrl = ("category.aspx?category=Other");
            }
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            


             

            if (TextBox1.Text.Length > 0)
            {
                if (Request.QueryString["user"] == null)
                {

                    Response.Redirect("search.aspx?search=" + TextBox1.Text);
                    
                }
                else
                {
                    Response.Redirect("search.aspx?search=" + TextBox1.Text + "&user=" + Request.QueryString["user"]);

                }

            }
            
        }
    }
}